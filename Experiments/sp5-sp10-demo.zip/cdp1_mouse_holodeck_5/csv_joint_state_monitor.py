@nrp.MapRobotSubscriber("muscle_state", Topic('/gazebo_muscle_interface/robot/muscle_states', sensor_msgs.msg.MuscleStates))
@nrp.MapCSVRecorder("recorder", filename="humerus2_force.csv", headers=["Name", "time", "Force"])
@nrp.Robot2Neuron()
def csv_joint_state_monitor (t, muscle_state, recorder):
    if not isinstance(muscle_state.value, type(None)):
        for i in range(0, len(muscle_state.value.name)):
            recorder.record_entry(muscle_state.value.name[i], t, muscle_state.value.position[i])