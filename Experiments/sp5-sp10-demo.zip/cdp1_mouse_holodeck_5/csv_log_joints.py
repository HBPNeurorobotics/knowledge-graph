@nrp.Robot2Neuron()
def csv_log_joints (t):
    #log the first timestep (20ms), each couple of seconds
    if t % 2 < 0.02:
        clientLogger.info('Time: ', t)