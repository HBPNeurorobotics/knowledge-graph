from gazebo_ros_muscle_interface.msg import MuscleStates
@nrp.MapCSVRecorder("recorder", filename="muscle_forces.csv", headers=["name", "force", "time"])
@nrp.MapRobotSubscriber("muscles", Topic('/gazebo_muscle_interface/robot/muscle_states', MuscleStates))
@nrp.Robot2Neuron()
def csv_muscle_forces (t, muscles, recorder):
    if not isinstance(muscles.value, type(None)):
        for m in muscles.value.muscles:
            # record the current robot position
            recorder.record_entry(m.name,
                                  m.force,
                                  t)
